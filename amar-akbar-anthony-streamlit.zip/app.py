
import streamlit as st
import pandas as pd
import simulator

st.set_page_config(page_title="Amar Akbar Anthony Predictor", layout="wide")

st.title("🎴 Amar Akbar Anthony — Live Casino Predictor")
st.subheader("Fair, Transparent, Predictive Game Simulation")

# Load or create fairness log
try:
    log_df = pd.read_csv("fairness_log.csv")
except:
    log_df = pd.DataFrame(columns=["timestamp", "discarded", "scanned", "result"])

# Run simulation
if st.button("🎲 Run Next Round"):
    log_entry = simulator.simulate_round()
    if log_entry:
        log_df = pd.concat([log_df, pd.DataFrame([log_entry])], ignore_index=True)
        log_df.to_csv("fairness_log.csv", index=False)

# Predict Amar every time
st.markdown("### 🔮 Next Round Prediction: **Amar**")

# Live metrics
amar_count = (log_df['result'] == 'Amar').sum()
akbar_count = (log_df['result'] == 'Akbar').sum()
anthony_count = (log_df['result'] == 'Anthony').sum()
total = len(log_df)

if total > 0:
    st.metric("✅ Prediction Success Rate", f"{(amar_count/total)*100:.2f}%")
else:
    st.metric("✅ Prediction Success Rate", "N/A")

# Display recent results
st.markdown("### 📋 Last 20 Rounds")
st.dataframe(log_df.tail(20).sort_index(ascending=False))

# Win distribution bar chart
st.markdown("### 📊 Win Distribution")
st.bar_chart(log_df['result'].value_counts())

# Expected vs Actual comparison
expected = pd.Series({'Amar': 46.15, 'Akbar': 30.77, 'Anthony': 23.08})
actual = log_df['result'].value_counts(normalize=True) * 100
compare_df = pd.concat([expected, actual], axis=1)
compare_df.columns = ['Expected %', 'Actual %']
st.bar_chart(compare_df)

# Fairness log display
st.markdown("### 📝 Fairness Audit Log")
st.dataframe(log_df.tail(50).sort_index(ascending=False))
