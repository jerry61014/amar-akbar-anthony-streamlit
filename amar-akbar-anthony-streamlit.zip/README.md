
# Amar Akbar Anthony — Casino Predictor (Streamlit)

This is a live simulation of the Amar Akbar Anthony card game predictor built using Python and Streamlit.

## 🎮 Features:
- Predicts **Amar** every round (statistically optimal)
- Tracks win distribution, fairness logs, and prediction success rate
- Real-time interactive dashboard with charts and logs

## 🚀 How to Run Locally

```bash
pip install -r requirements.txt
streamlit run app.py
```

## 🌐 Deploy on Streamlit Cloud

1. Upload this project to your GitHub.
2. Go to [https://streamlit.io/cloud](https://streamlit.io/cloud).
3. Click **New App**.
4. Connect your GitHub repo.
5. Set:
    - **Main file:** `app.py`
6. Click **Deploy**.

Enjoy! 🎴🎲
